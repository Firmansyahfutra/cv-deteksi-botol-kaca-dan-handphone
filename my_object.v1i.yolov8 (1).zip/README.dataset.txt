# my_object > 2026-01-09 6:37pm
https://universe.roboflow.com/bentuk-benda/my_object-tz9em-f9sel

Provided by a Roboflow user
License: CC BY 4.0

